package com.dmbteam.catalogapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;


/**
 * The Class ParseReceiver.
 */
public class ParseReceiver extends BroadcastReceiver {
	
	/** The tag. */
	private final String TAG = "Parse Notification";
	
	/** The msg. */
	private String msg = "";

	/* (non-Javadoc)
	 * @see android.content.BroadcastReceiver#onReceive(android.content.Context, android.content.Intent)
	 */
	@Override
	public void onReceive(Context ctx, Intent intent) {

	}

}
